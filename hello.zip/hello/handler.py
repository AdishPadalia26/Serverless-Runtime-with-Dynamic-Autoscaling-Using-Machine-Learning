def handle(req):
    return f"Hello from OpenFaaS! Input: {req}"

